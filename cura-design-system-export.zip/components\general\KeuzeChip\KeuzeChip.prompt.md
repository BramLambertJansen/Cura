KeuzeChip from cura. Use via `window.Cura.KeuzeChip` (bundle loaded from the root `_ds_bundle.js`).
