# Cura design system — building with these components

Cura is a calm, shared household planner for two people (React 19 + Tailwind v4 +
shadcn/Radix). **UI language is Dutch**; the tone is warm, forgiving, never
competitive. Deliberately avoid: summary percentages ("78% opgeruimd"), hard
streaks ("12 dagen op rij"), person-vs-person scoreboards, and alarming/overdue
red states. Prefer soft, honest phrasing ("Waarschijnlijk weer toe").

## Setup & wrapping
- **Styling needs no provider.** Components are pre-styled by the shipped
  stylesheet (tokens + Tailwind utilities). Just ensure `styles.css` is loaded.
- **Router context:** `RoutineKaart`, `RoutineKaartCompact`, and `FocusMiniPill`
  call `useNavigate`, so render them inside a react-router router (e.g. wrap the
  screen in `<MemoryRouter>` / `<BrowserRouter>`), or they throw.
- **Toasts:** feedback uses `sonner` — mount its `<Toaster/>` once at the app root
  if you use toast-driven components (`ConnectivityBanner`, `UpdatePrompt`).
- **App shell:** Cura is a fixed, full-bleed PWA layer on the cream
  `bg-background`, NOT a scrolling document — only the content area scrolls, a
  bottom nav sits at the bottom, and `Sheet` overlays render at shell level
  (absolute) over the content.

## Styling idiom — Tailwind utilities bound to Cura tokens
Style with these utility families (all defined in the DS stylesheet). Don't invent
hex values or hand-roll buttons/cards — compose the components below and use these
classes only for layout glue.

| Purpose | Classes |
|---|---|
| Surfaces | `bg-background` (cream page), `bg-card` (warm white), `bg-card-active` (warmer day-view card), `bg-card-room`, `bg-secondary`, `bg-muted`, `bg-accent` |
| Text | `text-foreground`, `text-muted-foreground`, `text-primary` (sage), `text-white` (on the sage CTA) |
| Brand / primary | sage `--primary` (#496E46); the full-width CTA uses the `--gradient-primary` gradient (via `PrimaryButton`) |
| Borders / radius | `border-border`; the calm look is large radii — `rounded-2xl`, `rounded-3xl`, `rounded-full` |
| Typography | body is Plus Jakarta Sans (default); headings & numeric displays use the `font-display` utility (Lora serif), often `italic` for soft hints |
| Focus | the `focus-ring` utility (a 2px sage halo) — don't hand-type focus-visible chains |

Derived tints follow `color-mix(in srgb, var(--token) X%, transparent)` — reuse a
token rather than a new color.

## Compose Cura's own components (don't rebuild them)
- Primitives (`components/general/…`): `Card`, `PrimaryButton`, `DubbelKnop`,
  `PillButton`, `IconButton`, `KeuzeChip`, `StatusBadge`, `Checkbox`, `Toggle`,
  `VeldInput`, `VeldTextarea`, `Sheet`, `PageHeader`, `Kop`, `Leeg`, `HintBanner`.
- Domain rows/cards take a plain view-model object (see each `.d.ts`): `TaakRij`
  and `TijdlijnTaakRij` take a `TaskView`; `KamerKaart` a `RoomView`;
  `RoutineKaart`/`RoutineKaartCompact` a `RoutineView`; `BoodschapRij` a
  `ShoppingItemView`; `SuggestieRij` a `TaskView`. These are display models —
  construct literals, don't fetch.
- Room art degrades gracefully: `KamerKaart`/`RoomThumb`/`RoomArt` show a tinted
  wash + line icon when the room's `iconKey` has no watercolor asset present.

## Where the truth lives
Read the bound stylesheet (`styles.css` and its `@import` closure, incl. the
`:root` token block) before styling, and each component's `.d.ts` (props) +
`.prompt.md` (usage) before composing it.

## Idiomatic snippet
```tsx
import { PageHeader, Card, TaakRij, PrimaryButton } from 'cura';

function Vandaag() {
  return (
    <div className="bg-background min-h-full px-5 pt-14">
      <PageHeader title="Vandaag" subtitle="Nog twee taken te gaan." />
      <div className="bg-card-active border border-border rounded-2xl p-1 space-y-1">
        <TaakRij task={{ id: '1', title: 'Aanrecht afnemen', room: 'Keuken', duration: '5 min', planned: true, done: false }} onToggle={() => {}} onEdit={() => {}} />
        <TaakRij task={{ id: '2', title: 'Planten water geven', room: 'Woonkamer', done: false, planned: false }} onToggle={() => {}} onEdit={() => {}} />
      </div>
      <div className="mt-6"><PrimaryButton onClick={() => {}}>Taak toevoegen</PrimaryButton></div>
    </div>
  );
}
```

# Cura (cura@0.1.0)

This design system is the published cura React library, bundled as a single
browser global. All 61 components are the real upstream code.

## Where things are

- `_ds_bundle.js` — the whole-DS bundle at the project root; loads every component to `window.Cura`. First line is a `/* @ds-bundle: … */` metadata header.
- `styles.css` — the single stylesheet entry: it `@import`s the tokens, fonts, and component styles (`_ds_bundle.css`). Link this one file.
- `components/<group>/<Name>/<Name>.prompt.md` (example JSX + variants), `<Name>.d.ts` (types), `<Name>.html` (variant grid).
- `tokens/*.css` — CSS custom properties, names verbatim from upstream.
- `fonts/` — `@font-face` files + `fonts.css` (when the package ships fonts).

For a specific component, `read_file("components/<group>/<Name>/<Name>.prompt.md")`.

## Loading

Add these two lines to your page once (React must be on the page first):

```html
<link rel="stylesheet" href="styles.css">
<script src="_ds_bundle.js"></script>
```

Components are then available at `window.Cura.*`. Mount into a dedicated child node (e.g. `<div id="ds-root">`), not the host page's own React root, so the two trees don't collide:

```jsx
const { ActiviteitReacties } = window.Cura;
ReactDOM.createRoot(document.getElementById('ds-root')).render(<ActiviteitReacties />);
```

## Tokens

153 CSS custom properties from cura. Names are
preserved verbatim from upstream. They are declared inside `_ds_bundle.css` (this DS ships one compiled stylesheet rather than separate token files).

- **color** (34): `--tw-border-style`, `--tw-shadow-color`, `--tw-inset-shadow-color`, …
- **spacing** (6): `--tw-space-y-reverse`, `--tw-space-x-reverse`, `--tw-inset-shadow`, …
- **typography** (13): `--tw-font-weight`, `--tw-tracking`, `--font-sans`, …
- **radius** (3): `--radius-2xl`, `--radius-3xl`, `--radius`
- **shadow** (15): `--tw-shadow`, `--tw-shadow-alpha`, `--tw-ring-shadow`, …
- **other** (82): `--tw-translate-x`, `--tw-translate-y`, `--tw-translate-z`, …

## Components

### general
- `ActiviteitReacties`
- `AppBackground`
- `Avatar`
- `BoodschapRij`
- `Button`
- `Calendar`
- `Card`
- `CardSkeleton`
- `Checkbox`
- `ConnectivityBanner`
- `DubbelKnop`
- `EmptyIllustration`
- `ErrorBoundary`
- `FieldShell`
- `FocusMiniPill`
- `FullScreenError`
- `FullScreenSkeleton`
- `GroupCard`
- `HintBanner`
- `IconBadge`
- `IconButton`
- `InstRij`
- `KamerKaart`
- `KamerKunstKiezer`
- `KeuzeChip`
- `Kop`
- `LandingHeader`
- `Leeg`
- `ListSkeleton`
- `Logo`
- `OptieKaart`
- `PageBanner`
- `PageHeader`
- `PageSkeleton`
- `PillButton`
- `Popover`
- `PopoverAnchor`
- `PopoverContent`
- `PopoverTrigger`
- `PrimaryButton`
- `PullToRefreshIndicator`
- `RingProgress`
- `RoomArt`
- `RoomHero`
- `RoomThumb`
- `RoutineKaart`
- `RoutineKaartCompact`
- `Sheet`
- `SheetHeader`
- `StatusBadge`
- `SuggestieRij`
- `TaakRij`
- `TaakToevoegRij`
- `TijdlijnTaakRij`
- `TimerDisplay`
- `Toggle`
- `UpdatePrompt`
- `VeldInput`
- `VeldTextarea`
- `VerwijderKnop`

### figma
- `ImageWithFallback`
