// Re-export of cura@0.1.0 KamerKaart. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { KamerKaart: window.Cura.KamerKaart });
