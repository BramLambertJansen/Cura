import * as React from 'react';

/**
 * Calendar — from cura@0.1.0.
 */
export interface CalendarProps {
  [key: string]: unknown;
}

export declare const Calendar: React.ComponentType<CalendarProps>;
