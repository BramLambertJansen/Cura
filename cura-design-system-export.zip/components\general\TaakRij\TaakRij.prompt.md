TaakRij from cura. Use via `window.Cura.TaakRij` (bundle loaded from the root `_ds_bundle.js`).
