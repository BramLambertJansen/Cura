Avatar from cura. Use via `window.Cura.Avatar` (bundle loaded from the root `_ds_bundle.js`).
