import * as React from 'react';

/**
 * RoutineKaartCompact — from cura@0.1.0.
 */
export interface RoutineKaartCompactProps {
  [key: string]: unknown;
}

export declare const RoutineKaartCompact: React.ComponentType<RoutineKaartCompactProps>;
