import * as React from 'react';

/**
 * Avatar — from cura@0.1.0.
 */
export interface AvatarProps {
  [key: string]: unknown;
}

export declare const Avatar: React.ComponentType<AvatarProps>;
