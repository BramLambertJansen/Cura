// Re-export of cura@0.1.0 Kop. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { Kop: window.Cura.Kop });
