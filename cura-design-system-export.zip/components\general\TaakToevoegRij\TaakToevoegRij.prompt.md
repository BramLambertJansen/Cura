TaakToevoegRij from cura. Use via `window.Cura.TaakToevoegRij` (bundle loaded from the root `_ds_bundle.js`).
