// Re-export of cura@0.1.0 FieldShell. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { FieldShell: window.Cura.FieldShell });
