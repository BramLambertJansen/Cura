FullScreenSkeleton from cura. Use via `window.Cura.FullScreenSkeleton` (bundle loaded from the root `_ds_bundle.js`).
