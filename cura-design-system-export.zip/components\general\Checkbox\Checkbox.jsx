// Re-export of cura@0.1.0 Checkbox. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { Checkbox: window.Cura.Checkbox });
