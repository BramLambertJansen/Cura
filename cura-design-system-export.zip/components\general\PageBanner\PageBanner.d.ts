import * as React from 'react';

/**
 * PageBanner — from cura@0.1.0.
 */
export interface PageBannerProps {
  [key: string]: unknown;
}

export declare const PageBanner: React.ComponentType<PageBannerProps>;
