Checkbox from cura. Use via `window.Cura.Checkbox` (bundle loaded from the root `_ds_bundle.js`).
