import * as React from 'react';

/**
 * RoutineKaart — from cura@0.1.0.
 */
export interface RoutineKaartProps {
  [key: string]: unknown;
}

export declare const RoutineKaart: React.ComponentType<RoutineKaartProps>;
