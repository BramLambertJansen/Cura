PullToRefreshIndicator from cura. Use via `window.Cura.PullToRefreshIndicator` (bundle loaded from the root `_ds_bundle.js`).

The calm water-drop that answers a pull-to-refresh gesture: it fades and
turns in with the pull, then breathes (same .skeleton-breathe as the
skeletons) while the refresh runs — never a spinner. Purely visual; the
gesture itself lives in usePullToRefresh.
