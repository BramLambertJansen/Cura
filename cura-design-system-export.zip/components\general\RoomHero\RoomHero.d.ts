import * as React from 'react';

/**
 * RoomHero — from cura@0.1.0.
 */
export interface RoomHeroProps {
  [key: string]: unknown;
}

export declare const RoomHero: React.ComponentType<RoomHeroProps>;
