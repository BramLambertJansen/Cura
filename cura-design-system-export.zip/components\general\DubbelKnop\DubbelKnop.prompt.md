DubbelKnop from cura. Use via `window.Cura.DubbelKnop` (bundle loaded from the root `_ds_bundle.js`).
