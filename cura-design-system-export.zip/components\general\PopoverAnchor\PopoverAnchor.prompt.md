PopoverAnchor from cura. Use via `window.Cura.PopoverAnchor` (bundle loaded from the root `_ds_bundle.js`).
