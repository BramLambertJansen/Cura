StatusBadge from cura. Use via `window.Cura.StatusBadge` (bundle loaded from the root `_ds_bundle.js`).
