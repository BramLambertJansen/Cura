Sheet from cura. Use via `window.Cura.Sheet` (bundle loaded from the root `_ds_bundle.js`).

## Related

`SheetHeader`
