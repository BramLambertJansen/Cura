import * as React from 'react';

/**
 * SheetHeader — from cura@0.1.0.
 */
export interface SheetHeaderProps {
  [key: string]: unknown;
}

export declare const SheetHeader: React.ComponentType<SheetHeaderProps>;
