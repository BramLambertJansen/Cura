// Re-export of cura@0.1.0 UpdatePrompt. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { UpdatePrompt: window.Cura.UpdatePrompt });
