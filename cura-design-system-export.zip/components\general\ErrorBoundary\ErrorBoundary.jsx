// Re-export of cura@0.1.0 ErrorBoundary. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { ErrorBoundary: window.Cura.ErrorBoundary });
