RoutineKaartCompact from cura. Use via `window.Cura.RoutineKaartCompact` (bundle loaded from the root `_ds_bundle.js`).
