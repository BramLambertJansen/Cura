// Re-export of cura@0.1.0 PillButton. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { PillButton: window.Cura.PillButton });
