// Re-export of cura@0.1.0 RoutineKaartCompact. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { RoutineKaartCompact: window.Cura.RoutineKaartCompact });
