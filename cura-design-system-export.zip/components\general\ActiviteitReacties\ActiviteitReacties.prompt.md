ActiviteitReacties from cura. Use via `window.Cura.ActiviteitReacties` (bundle loaded from the root `_ds_bundle.js`).

Three subtle, one-tap reactions on a Samen activity row — no scores, no ranking, just warmth.
