PageBanner from cura. Use via `window.Cura.PageBanner` (bundle loaded from the root `_ds_bundle.js`).

Decorative watercolor backdrop behind a page header — the in-page sibling of
LandingHeader. Absolutely positioned against the top of the page (the caller
makes its root `relative`), fading into --background at the bottom so the
header text stays readable without a scrim: the art's cream sky already
matches the app background (CLAUDE.md §7, derive from tokens). Renders
nothing when the file is missing or fails, so layout never depends on it.
