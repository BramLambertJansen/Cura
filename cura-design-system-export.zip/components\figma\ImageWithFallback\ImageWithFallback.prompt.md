ImageWithFallback from cura. Use via `window.Cura.ImageWithFallback` (bundle loaded from the root `_ds_bundle.js`).
