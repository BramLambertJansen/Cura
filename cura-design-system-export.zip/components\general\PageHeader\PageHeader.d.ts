import * as React from 'react';

/**
 * PageHeader — from cura@0.1.0.
 */
export interface PageHeaderProps {
  [key: string]: unknown;
}

export declare const PageHeader: React.ComponentType<PageHeaderProps>;
