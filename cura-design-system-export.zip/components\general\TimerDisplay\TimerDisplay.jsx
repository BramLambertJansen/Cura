// Re-export of cura@0.1.0 TimerDisplay. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { TimerDisplay: window.Cura.TimerDisplay });
