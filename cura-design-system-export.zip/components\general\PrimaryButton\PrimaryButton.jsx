// Re-export of cura@0.1.0 PrimaryButton. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { PrimaryButton: window.Cura.PrimaryButton });
