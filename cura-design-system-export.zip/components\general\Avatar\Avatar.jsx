// Re-export of cura@0.1.0 Avatar. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { Avatar: window.Cura.Avatar });
