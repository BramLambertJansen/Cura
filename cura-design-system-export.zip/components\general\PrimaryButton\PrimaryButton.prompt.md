PrimaryButton from cura. Use via `window.Cura.PrimaryButton` (bundle loaded from the root `_ds_bundle.js`).
