// Re-export of cura@0.1.0 GroupCard. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { GroupCard: window.Cura.GroupCard });
