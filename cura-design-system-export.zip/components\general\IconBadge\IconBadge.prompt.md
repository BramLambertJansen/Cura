IconBadge from cura. Use via `window.Cura.IconBadge` (bundle loaded from the root `_ds_bundle.js`).
