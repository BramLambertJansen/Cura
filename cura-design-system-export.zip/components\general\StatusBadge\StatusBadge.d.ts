import * as React from 'react';

/**
 * StatusBadge — from cura@0.1.0.
 */
export interface StatusBadgeProps {
  [key: string]: unknown;
}

export declare const StatusBadge: React.ComponentType<StatusBadgeProps>;
