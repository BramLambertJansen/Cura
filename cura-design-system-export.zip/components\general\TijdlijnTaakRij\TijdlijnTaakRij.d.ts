import * as React from 'react';

/**
 * TijdlijnTaakRij — from cura@0.1.0.
 */
export interface TijdlijnTaakRijProps {
  [key: string]: unknown;
}

export declare const TijdlijnTaakRij: React.ComponentType<TijdlijnTaakRijProps>;
