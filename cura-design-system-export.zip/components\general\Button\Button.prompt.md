Button from cura. Use via `window.Cura.Button` (bundle loaded from the root `_ds_bundle.js`).
