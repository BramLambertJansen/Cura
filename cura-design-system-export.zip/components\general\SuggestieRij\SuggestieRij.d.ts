import * as React from 'react';

/**
 * SuggestieRij — from cura@0.1.0.
 */
export interface SuggestieRijProps {
  [key: string]: unknown;
}

export declare const SuggestieRij: React.ComponentType<SuggestieRijProps>;
