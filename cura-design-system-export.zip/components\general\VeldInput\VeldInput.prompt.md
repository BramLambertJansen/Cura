VeldInput from cura. Use via `window.Cura.VeldInput` (bundle loaded from the root `_ds_bundle.js`).
