// Re-export of cura@0.1.0 Card. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { Card: window.Cura.Card });
