FullScreenError from cura. Use via `window.Cura.FullScreenError` (bundle loaded from the root `_ds_bundle.js`).

Calm full-screen error for gates in front of the app shell — mirrors
FullScreenSkeleton's background/safe-area treatment so a failed initial load
feels like a gentle "let's try again", not a crash (CLAUDE.md §1-2: forgiving,
never alarming). Distinct from ErrorBoundary (which catches render-time throws
and can only offer a hard reload); this one retries in place via onRetry.
