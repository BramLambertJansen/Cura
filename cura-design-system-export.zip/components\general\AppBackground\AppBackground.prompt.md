AppBackground from cura. Use via `window.Cura.AppBackground` (bundle loaded from the root `_ds_bundle.js`).

The same soft sage/peach pattern used in the iOS splash screens (public/splash/*) — fixed full-bleed layer so the in-app experience matches the PWA launch screen. Served as WebP (8 KB vs the 900 KB source PNG, which only lives on as the splash-screen artwork).
