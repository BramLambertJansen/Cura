// Re-export of cura@0.1.0 EmptyIllustration. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { EmptyIllustration: window.Cura.EmptyIllustration });
