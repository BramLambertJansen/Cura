import * as React from 'react';

/**
 * InstRij — from cura@0.1.0.
 */
export interface InstRijProps {
  [key: string]: unknown;
}

export declare const InstRij: React.ComponentType<InstRijProps>;
