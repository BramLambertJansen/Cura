// Re-export of cura@0.1.0 PopoverTrigger. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { PopoverTrigger: window.Cura.PopoverTrigger });
