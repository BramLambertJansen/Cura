import * as React from 'react';

/**
 * FocusMiniPill — from cura@0.1.0.
 */
export interface FocusMiniPillProps {
  [key: string]: unknown;
}

export declare const FocusMiniPill: React.ComponentType<FocusMiniPillProps>;
