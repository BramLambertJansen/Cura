RoomHero from cura. Use via `window.Cura.RoomHero` (bundle loaded from the root `_ds_bundle.js`).
