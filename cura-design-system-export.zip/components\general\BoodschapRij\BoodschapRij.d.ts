import * as React from 'react';

/**
 * BoodschapRij — from cura@0.1.0.
 */
export interface BoodschapRijProps {
  [key: string]: unknown;
}

export declare const BoodschapRij: React.ComponentType<BoodschapRijProps>;
