SheetHeader from cura. Use via `window.Cura.SheetHeader` (bundle loaded from the root `_ds_bundle.js`).
