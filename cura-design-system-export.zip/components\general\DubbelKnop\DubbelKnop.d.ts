import * as React from 'react';

/**
 * DubbelKnop — from cura@0.1.0.
 */
export interface DubbelKnopProps {
  [key: string]: unknown;
}

export declare const DubbelKnop: React.ComponentType<DubbelKnopProps>;
