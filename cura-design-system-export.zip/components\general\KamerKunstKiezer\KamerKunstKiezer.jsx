// Re-export of cura@0.1.0 KamerKunstKiezer. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { KamerKunstKiezer: window.Cura.KamerKunstKiezer });
