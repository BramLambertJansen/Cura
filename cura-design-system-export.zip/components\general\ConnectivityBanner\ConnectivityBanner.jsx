// Re-export of cura@0.1.0 ConnectivityBanner. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { ConnectivityBanner: window.Cura.ConnectivityBanner });
