import * as React from 'react';

/**
 * PopoverAnchor — from cura@0.1.0.
 */
export interface PopoverAnchorProps {
  [key: string]: unknown;
}

export declare const PopoverAnchor: React.ComponentType<PopoverAnchorProps>;
