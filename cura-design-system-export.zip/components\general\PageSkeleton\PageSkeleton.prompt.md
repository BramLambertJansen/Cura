PageSkeleton from cura. Use via `window.Cura.PageSkeleton` (bundle loaded from the root `_ds_bundle.js`).
