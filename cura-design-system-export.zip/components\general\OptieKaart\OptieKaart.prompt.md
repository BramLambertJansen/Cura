OptieKaart from cura. Use via `window.Cura.OptieKaart` (bundle loaded from the root `_ds_bundle.js`).
