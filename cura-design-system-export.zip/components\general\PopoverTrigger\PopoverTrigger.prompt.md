PopoverTrigger from cura. Use via `window.Cura.PopoverTrigger` (bundle loaded from the root `_ds_bundle.js`).
