HintBanner from cura. Use via `window.Cura.HintBanner` (bundle loaded from the root `_ds_bundle.js`).
