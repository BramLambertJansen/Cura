ErrorBoundary from cura. Use via `window.Cura.ErrorBoundary` (bundle loaded from the root `_ds_bundle.js`).

Catches render-time errors anywhere below it so a crash shows a calm recovery message instead of a blank white screen (CLAUDE.md §1-2 tone: forgiving, never alarming).
