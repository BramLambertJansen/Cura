import * as React from 'react';

/**
 * ListSkeleton — from cura@0.1.0.
 */
export interface ListSkeletonProps {
  [key: string]: unknown;
}

export declare const ListSkeleton: React.ComponentType<ListSkeletonProps>;
