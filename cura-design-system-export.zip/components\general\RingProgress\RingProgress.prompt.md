RingProgress from cura. Use via `window.Cura.RingProgress` (bundle loaded from the root `_ds_bundle.js`).
