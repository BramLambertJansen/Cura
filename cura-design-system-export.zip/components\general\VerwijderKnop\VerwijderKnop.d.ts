import * as React from 'react';

/**
 * VerwijderKnop — from cura@0.1.0.
 */
export interface VerwijderKnopProps {
  [key: string]: unknown;
}

export declare const VerwijderKnop: React.ComponentType<VerwijderKnopProps>;
