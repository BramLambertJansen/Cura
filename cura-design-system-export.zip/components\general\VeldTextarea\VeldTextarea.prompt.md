VeldTextarea from cura. Use via `window.Cura.VeldTextarea` (bundle loaded from the root `_ds_bundle.js`).
