import * as React from 'react';

/**
 * ImageWithFallback — from cura@0.1.0.
 */
export interface ImageWithFallbackProps {
  [key: string]: unknown;
}

export declare const ImageWithFallback: React.ComponentType<ImageWithFallbackProps>;
