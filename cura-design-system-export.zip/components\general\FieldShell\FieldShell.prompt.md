FieldShell from cura. Use via `window.Cura.FieldShell` (bundle loaded from the root `_ds_bundle.js`).
