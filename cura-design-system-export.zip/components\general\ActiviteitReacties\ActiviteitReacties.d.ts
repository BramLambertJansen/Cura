import * as React from 'react';

/**
 * ActiviteitReacties — from cura@0.1.0.
 */
export interface ActiviteitReactiesProps {
  [key: string]: unknown;
}

export declare const ActiviteitReacties: React.ComponentType<ActiviteitReactiesProps>;
