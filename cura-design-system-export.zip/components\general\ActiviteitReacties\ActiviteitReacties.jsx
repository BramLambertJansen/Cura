// Re-export of cura@0.1.0 ActiviteitReacties. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { ActiviteitReacties: window.Cura.ActiviteitReacties });
