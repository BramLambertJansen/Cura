EmptyIllustration from cura. Use via `window.Cura.EmptyIllustration` (bundle loaded from the root `_ds_bundle.js`).

Calm watercolor illustration for gentle empty states — never an alarming
"niets hier" (CLAUDE.md §2). Defaults to the sprout-in-clouds art
(public/empty-cloud.webp); pass `src` for a scene-specific one (e.g.
/empty-plants.webp on Vandaag). Renders nothing if the file is missing,
so callers keep their text-only empty state.
