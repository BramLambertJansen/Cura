import * as React from 'react';

/**
 * VeldTextarea — from cura@0.1.0.
 */
export interface VeldTextareaProps {
  [key: string]: unknown;
}

export declare const VeldTextarea: React.ComponentType<VeldTextareaProps>;
