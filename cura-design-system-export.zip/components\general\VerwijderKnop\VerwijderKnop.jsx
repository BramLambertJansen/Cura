// Re-export of cura@0.1.0 VerwijderKnop. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { VerwijderKnop: window.Cura.VerwijderKnop });
