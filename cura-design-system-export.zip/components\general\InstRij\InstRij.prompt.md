InstRij from cura. Use via `window.Cura.InstRij` (bundle loaded from the root `_ds_bundle.js`).
