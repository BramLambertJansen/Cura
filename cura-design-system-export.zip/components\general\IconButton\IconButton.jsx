// Re-export of cura@0.1.0 IconButton. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { IconButton: window.Cura.IconButton });
