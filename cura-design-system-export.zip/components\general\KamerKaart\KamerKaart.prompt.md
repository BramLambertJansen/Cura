KamerKaart from cura. Use via `window.Cura.KamerKaart` (bundle loaded from the root `_ds_bundle.js`).
