// Re-export of cura@0.1.0 InstRij. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { InstRij: window.Cura.InstRij });
