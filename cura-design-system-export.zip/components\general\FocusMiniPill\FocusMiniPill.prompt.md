FocusMiniPill from cura. Use via `window.Cura.FocusMiniPill` (bundle loaded from the root `_ds_bundle.js`).

Klein zwevend pilletje dat verschijnt zodra de focustimer loopt (of gepauzeerd
is) en je NIET op het focus-scherm bent — tik = terug naar de timer. Zit
linksonder, boven de `BottomNav` en naast de gecentreerde FAB, zodat het niks
overlapt. De tik-hook op MainShell-niveau houdt de tijd bij; dit pilletje
rendert alleen mee.
