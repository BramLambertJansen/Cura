// Re-export of cura@0.1.0 RoomThumb. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { RoomThumb: window.Cura.RoomThumb });
