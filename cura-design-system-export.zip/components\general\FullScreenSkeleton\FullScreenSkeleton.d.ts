import * as React from 'react';

/**
 * FullScreenSkeleton — from cura@0.1.0.
 */
export interface FullScreenSkeletonProps {
  [key: string]: unknown;
}

export declare const FullScreenSkeleton: React.ComponentType<FullScreenSkeletonProps>;
