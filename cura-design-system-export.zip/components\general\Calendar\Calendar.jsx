// Re-export of cura@0.1.0 Calendar. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { Calendar: window.Cura.Calendar });
