SuggestieRij from cura. Use via `window.Cura.SuggestieRij` (bundle loaded from the root `_ds_bundle.js`).

A single "misschien handig"-suggestion — plan it or wave it off, both
reversible. Sits directly inside the "Misschien handig" group-card (see
VandaagPage) without its own shadow/border — a flatter --card fill nested
in that card's warmer --card-active, the same nesting the dagdeel-tijdlijn
rows use.
