PageHeader from cura. Use via `window.Cura.PageHeader` (bundle loaded from the root `_ds_bundle.js`).
