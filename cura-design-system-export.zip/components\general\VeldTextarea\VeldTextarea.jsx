// Re-export of cura@0.1.0 VeldTextarea. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { VeldTextarea: window.Cura.VeldTextarea });
