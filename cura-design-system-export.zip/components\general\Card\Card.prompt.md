Card from cura. Use via `window.Cura.Card` (bundle loaded from the root `_ds_bundle.js`).

## Related

`CardSkeleton`
