import * as React from 'react';

/**
 * LandingHeader — from cura@0.1.0.
 */
export interface LandingHeaderProps {
  [key: string]: unknown;
}

export declare const LandingHeader: React.ComponentType<LandingHeaderProps>;
