import * as React from 'react';

/**
 * FullScreenError — from cura@0.1.0.
 */
export interface FullScreenErrorProps {
  [key: string]: unknown;
}

export declare const FullScreenError: React.ComponentType<FullScreenErrorProps>;
