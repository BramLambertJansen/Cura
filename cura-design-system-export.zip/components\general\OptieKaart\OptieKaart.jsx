// Re-export of cura@0.1.0 OptieKaart. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { OptieKaart: window.Cura.OptieKaart });
