RoomThumb from cura. Use via `window.Cura.RoomThumb` (bundle loaded from the root `_ds_bundle.js`).

The square room avatar used on room cards, the room-detail header and the
artwork picker. Renders the watercolor illustration (`ic.image`) when it
exists and loads; otherwise — or when the file is still missing — falls back
to the tinted gradient tile with the line icon, so partial art degrades
gracefully (CLAUDE.md §3, "degrade gracefully with partial data"). Pass
`large` on bigger tiles (the picker) so the fallback uses the 40px `iconLg`
instead of the 18px avatar icon.
