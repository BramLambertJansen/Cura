// Re-export of cura@0.1.0 TijdlijnTaakRij. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { TijdlijnTaakRij: window.Cura.TijdlijnTaakRij });
