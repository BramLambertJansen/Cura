IconButton from cura. Use via `window.Cura.IconButton` (bundle loaded from the root `_ds_bundle.js`).
