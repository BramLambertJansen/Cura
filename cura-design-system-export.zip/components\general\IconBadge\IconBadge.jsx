// Re-export of cura@0.1.0 IconBadge. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { IconBadge: window.Cura.IconBadge });
