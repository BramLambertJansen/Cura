"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.Cura;
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs2(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs2;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs2 : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // .design-sync/previews/RoomThumb.tsx
  var RoomThumb_exports = {};
  __export(RoomThumb_exports, {
    Groot: () => Groot,
    Kamers: () => Kamers
  });
  init_define_import_meta_env();

  // ds-shim:ds
  var ds_exports = {};
  __export(ds_exports, {
    default: () => ds_default
  });
  init_define_import_meta_env();
  __reExport(ds_exports, __toESM(require_ds_raw()));
  var g = window.Cura;
  var ds_default = "default" in g ? g.default : g;

  // node_modules/.pnpm/lucide-react@0.487.0_react@19.0.0/node_modules/lucide-react/dist/esm/lucide-react.js
  init_define_import_meta_env();

  // node_modules/.pnpm/lucide-react@0.487.0_react@19.0.0/node_modules/lucide-react/dist/esm/createLucideIcon.js
  init_define_import_meta_env();
  var import_react2 = __toESM(require_react_shim());

  // node_modules/.pnpm/lucide-react@0.487.0_react@19.0.0/node_modules/lucide-react/dist/esm/shared/src/utils.js
  init_define_import_meta_env();
  var toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
  var toCamelCase = (string) => string.replace(
    /^([A-Z])|[\s-_]+(\w)/g,
    (match, p1, p2) => p2 ? p2.toUpperCase() : p1.toLowerCase()
  );
  var toPascalCase = (string) => {
    const camelCase = toCamelCase(string);
    return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
  };
  var mergeClasses = (...classes) => classes.filter((className, index, array) => {
    return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
  }).join(" ").trim();

  // node_modules/.pnpm/lucide-react@0.487.0_react@19.0.0/node_modules/lucide-react/dist/esm/Icon.js
  init_define_import_meta_env();
  var import_react = __toESM(require_react_shim());

  // node_modules/.pnpm/lucide-react@0.487.0_react@19.0.0/node_modules/lucide-react/dist/esm/defaultAttributes.js
  init_define_import_meta_env();
  var defaultAttributes = {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  };

  // node_modules/.pnpm/lucide-react@0.487.0_react@19.0.0/node_modules/lucide-react/dist/esm/Icon.js
  var Icon = (0, import_react.forwardRef)(
    ({
      color = "currentColor",
      size = 24,
      strokeWidth = 2,
      absoluteStrokeWidth,
      className = "",
      children,
      iconNode,
      ...rest
    }, ref) => {
      return (0, import_react.createElement)(
        "svg",
        {
          ref,
          ...defaultAttributes,
          width: size,
          height: size,
          stroke: color,
          strokeWidth: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
          className: mergeClasses("lucide", className),
          ...rest
        },
        [
          ...iconNode.map(([tag, attrs]) => (0, import_react.createElement)(tag, attrs)),
          ...Array.isArray(children) ? children : [children]
        ]
      );
    }
  );

  // node_modules/.pnpm/lucide-react@0.487.0_react@19.0.0/node_modules/lucide-react/dist/esm/createLucideIcon.js
  var createLucideIcon = (iconName, iconNode) => {
    const Component = (0, import_react2.forwardRef)(
      ({ className, ...props }, ref) => (0, import_react2.createElement)(Icon, {
        ref,
        iconNode,
        className: mergeClasses(
          `lucide-${toKebabCase(toPascalCase(iconName))}`,
          `lucide-${iconName}`,
          className
        ),
        ...props
      })
    );
    Component.displayName = toPascalCase(iconName);
    return Component;
  };

  // node_modules/.pnpm/lucide-react@0.487.0_react@19.0.0/node_modules/lucide-react/dist/esm/icons/bed-double.js
  init_define_import_meta_env();
  var __iconNode = [
    ["path", { d: "M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8", key: "1k78r4" }],
    ["path", { d: "M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4", key: "fb3tl2" }],
    ["path", { d: "M12 4v6", key: "1dcgq2" }],
    ["path", { d: "M2 18h20", key: "ajqnye" }]
  ];
  var BedDouble = createLucideIcon("bed-double", __iconNode);

  // node_modules/.pnpm/lucide-react@0.487.0_react@19.0.0/node_modules/lucide-react/dist/esm/icons/droplets.js
  init_define_import_meta_env();
  var __iconNode2 = [
    [
      "path",
      {
        d: "M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z",
        key: "1ptgy4"
      }
    ],
    [
      "path",
      {
        d: "M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2 4.9 4 6.5s3 3.5 3 5.5a6.98 6.98 0 0 1-11.91 4.97",
        key: "1sl1rz"
      }
    ]
  ];
  var Droplets = createLucideIcon("droplets", __iconNode2);

  // node_modules/.pnpm/lucide-react@0.487.0_react@19.0.0/node_modules/lucide-react/dist/esm/icons/sofa.js
  init_define_import_meta_env();
  var __iconNode3 = [
    ["path", { d: "M20 9V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v3", key: "1dgpiv" }],
    [
      "path",
      {
        d: "M2 16a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-5a2 2 0 0 0-4 0v1.5a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5V11a2 2 0 0 0-4 0z",
        key: "xacw8m"
      }
    ],
    ["path", { d: "M4 18v2", key: "jwo5n2" }],
    ["path", { d: "M20 18v2", key: "1ar1qi" }],
    ["path", { d: "M12 4v9", key: "oqhhn3" }]
  ];
  var Sofa = createLucideIcon("sofa", __iconNode3);

  // node_modules/.pnpm/lucide-react@0.487.0_react@19.0.0/node_modules/lucide-react/dist/esm/icons/utensils-crossed.js
  init_define_import_meta_env();
  var __iconNode4 = [
    ["path", { d: "m16 2-2.3 2.3a3 3 0 0 0 0 4.2l1.8 1.8a3 3 0 0 0 4.2 0L22 8", key: "n7qcjb" }],
    [
      "path",
      { d: "M15 15 3.3 3.3a4.2 4.2 0 0 0 0 6l7.3 7.3c.7.7 2 .7 2.8 0L15 15Zm0 0 7 7", key: "d0u48b" }
    ],
    ["path", { d: "m2.1 21.8 6.4-6.3", key: "yn04lh" }],
    ["path", { d: "m19 5-7 7", key: "194lzd" }]
  ];
  var UtensilsCrossed = createLucideIcon("utensils-crossed", __iconNode4);

  // .design-sync/previews/RoomThumb.tsx
  var import_jsx_runtime = __toESM(require_react_shim(), 1);
  var keuken = { key: "utensils", icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, { size: 18, "aria-hidden": "true" }), iconLg: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, { size: 40, "aria-hidden": "true" }), color: "#B8924A", label: "Keuken", defaultName: "Keuken" };
  var badkamer = { key: "droplets", icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Droplets, { size: 18, "aria-hidden": "true" }), iconLg: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Droplets, { size: 40, "aria-hidden": "true" }), color: "#5A8FA8", label: "Badkamer", defaultName: "Badkamer" };
  var slaapkamer = { key: "bed", icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BedDouble, { size: 18, "aria-hidden": "true" }), iconLg: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BedDouble, { size: 40, "aria-hidden": "true" }), color: "#496E46", label: "Slaapkamer", defaultName: "Slaapkamer" };
  var woonkamer = { key: "sofa", icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sofa, { size: 18, "aria-hidden": "true" }), iconLg: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sofa, { size: 40, "aria-hidden": "true" }), color: "#8B6EA8", label: "Woonkamer", defaultName: "Woonkamer" };
  function Kamers() {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.RoomThumb, { ic: keuken, color: keuken.color, className: "w-16 h-16" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.RoomThumb, { ic: badkamer, color: badkamer.color, className: "w-16 h-16" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.RoomThumb, { ic: slaapkamer, color: slaapkamer.color, className: "w-16 h-16" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.RoomThumb, { ic: woonkamer, color: woonkamer.color, className: "w-16 h-16" })
    ] });
  }
  function Groot() {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { width: 112, height: 112 }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.RoomThumb, { ic: keuken, color: keuken.color, className: "w-full h-full", large: true }) });
  }
  return __toCommonJS(RoomThumb_exports);
})();
/*! Bundled license information:

lucide-react/dist/esm/shared/src/utils.js:
lucide-react/dist/esm/defaultAttributes.js:
lucide-react/dist/esm/Icon.js:
lucide-react/dist/esm/createLucideIcon.js:
lucide-react/dist/esm/icons/bed-double.js:
lucide-react/dist/esm/icons/droplets.js:
lucide-react/dist/esm/icons/sofa.js:
lucide-react/dist/esm/icons/utensils-crossed.js:
lucide-react/dist/esm/lucide-react.js:
  (**
   * @license lucide-react v0.487.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)
*/
