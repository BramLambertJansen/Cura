// Re-export of cura@0.1.0 PopoverAnchor. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { PopoverAnchor: window.Cura.PopoverAnchor });
