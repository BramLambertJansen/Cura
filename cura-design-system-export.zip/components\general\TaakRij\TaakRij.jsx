// Re-export of cura@0.1.0 TaakRij. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { TaakRij: window.Cura.TaakRij });
