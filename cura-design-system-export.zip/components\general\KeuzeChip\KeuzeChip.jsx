// Re-export of cura@0.1.0 KeuzeChip. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { KeuzeChip: window.Cura.KeuzeChip });
