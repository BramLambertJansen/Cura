import * as React from 'react';

/**
 * RoomArt — from cura@0.1.0.
 */
export interface RoomArtProps {
  [key: string]: unknown;
}

export declare const RoomArt: React.ComponentType<RoomArtProps>;
