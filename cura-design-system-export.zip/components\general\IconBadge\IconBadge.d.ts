import * as React from 'react';

/**
 * IconBadge — from cura@0.1.0.
 */
export interface IconBadgeProps {
  [key: string]: unknown;
}

export declare const IconBadge: React.ComponentType<IconBadgeProps>;
