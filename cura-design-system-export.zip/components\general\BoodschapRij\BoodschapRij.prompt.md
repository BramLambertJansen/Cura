BoodschapRij from cura. Use via `window.Cura.BoodschapRij` (bundle loaded from the root `_ds_bundle.js`).

A single boodschappenlijst row: checkbox + title/aantal + direct delete.
The title area toggles too, because on a shopping trip the whole row should
feel easy to hit without turning delete into a risky accidental action.
