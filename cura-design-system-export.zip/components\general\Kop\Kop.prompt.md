Kop from cura. Use via `window.Cura.Kop` (bundle loaded from the root `_ds_bundle.js`).
