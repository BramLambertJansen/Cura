// Re-export of cura@0.1.0 PageBanner. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { PageBanner: window.Cura.PageBanner });
