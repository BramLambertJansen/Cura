// Re-export of cura@0.1.0 RingProgress. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { RingProgress: window.Cura.RingProgress });
