// Re-export of cura@0.1.0 Toggle. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { Toggle: window.Cura.Toggle });
