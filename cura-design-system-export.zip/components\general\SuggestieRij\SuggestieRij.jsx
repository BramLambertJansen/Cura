// Re-export of cura@0.1.0 SuggestieRij. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { SuggestieRij: window.Cura.SuggestieRij });
