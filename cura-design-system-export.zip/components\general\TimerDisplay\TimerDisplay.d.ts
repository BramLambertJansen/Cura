import * as React from 'react';

/**
 * TimerDisplay — from cura@0.1.0.
 */
export interface TimerDisplayProps {
  [key: string]: unknown;
}

export declare const TimerDisplay: React.ComponentType<TimerDisplayProps>;
