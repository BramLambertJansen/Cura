import * as React from 'react';

/**
 * PillButton — from cura@0.1.0.
 */
export interface PillButtonProps {
  [key: string]: unknown;
}

export declare const PillButton: React.ComponentType<PillButtonProps>;
