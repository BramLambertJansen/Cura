import * as React from 'react';

/**
 * PageSkeleton — from cura@0.1.0.
 */
export interface PageSkeletonProps {
  [key: string]: unknown;
}

export declare const PageSkeleton: React.ComponentType<PageSkeletonProps>;
