CardSkeleton from cura. Use via `window.Cura.CardSkeleton` (bundle loaded from the root `_ds_bundle.js`).
