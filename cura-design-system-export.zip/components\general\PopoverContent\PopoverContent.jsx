// Re-export of cura@0.1.0 PopoverContent. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { PopoverContent: window.Cura.PopoverContent });
