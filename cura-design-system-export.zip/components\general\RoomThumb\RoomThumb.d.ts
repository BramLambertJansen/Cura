import * as React from 'react';

/**
 * RoomThumb — from cura@0.1.0.
 */
export interface RoomThumbProps {
  [key: string]: unknown;
}

export declare const RoomThumb: React.ComponentType<RoomThumbProps>;
