// Re-export of cura@0.1.0 StatusBadge. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { StatusBadge: window.Cura.StatusBadge });
