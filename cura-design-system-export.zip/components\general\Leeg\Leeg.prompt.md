Leeg from cura. Use via `window.Cura.Leeg` (bundle loaded from the root `_ds_bundle.js`).
