// Re-export of cura@0.1.0 TaakToevoegRij. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { TaakToevoegRij: window.Cura.TaakToevoegRij });
