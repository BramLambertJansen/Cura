import * as React from 'react';

/**
 * AppBackground — from cura@0.1.0.
 */
export interface AppBackgroundProps {
  [key: string]: unknown;
}

export declare const AppBackground: React.ComponentType<AppBackgroundProps>;
