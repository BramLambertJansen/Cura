Calendar from cura. Use via `window.Cura.Calendar` (bundle loaded from the root `_ds_bundle.js`).
