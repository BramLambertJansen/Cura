// Re-export of cura@0.1.0 HintBanner. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { HintBanner: window.Cura.HintBanner });
