// Re-export of cura@0.1.0 RoomArt. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { RoomArt: window.Cura.RoomArt });
