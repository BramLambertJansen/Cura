LandingHeader from cura. Use via `window.Cura.LandingHeader` (bundle loaded from the root `_ds_bundle.js`).

Decorative full-bleed watercolor sunrise for the landing / auth screen. The
art (public/landing-header.webp) sits at the top edge and fades out at its
bottom into the app background via a mask gradient — the illustration's cream
sky already matches --background (CLAUDE.md §7: derive from tokens, don't
hardcode), so no hard background knockout is needed.

Purely decorative: the brand mark + wordmark + subtitle now live in the auth
card that rises over this art, so the header renders nothing when the image
is missing — the branding in the card is the graceful fallback.
