import * as React from 'react';

/**
 * KeuzeChip — from cura@0.1.0.
 */
export interface KeuzeChipProps {
  [key: string]: unknown;
}

export declare const KeuzeChip: React.ComponentType<KeuzeChipProps>;
