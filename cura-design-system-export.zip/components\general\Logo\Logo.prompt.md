Logo from cura. Use via `window.Cura.Logo` (bundle loaded from the root `_ds_bundle.js`).

Cura's mark — house + heart-leaf. Single source of truth lives in public/logo.svg (also the favicon).
