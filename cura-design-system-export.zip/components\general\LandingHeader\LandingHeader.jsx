// Re-export of cura@0.1.0 LandingHeader. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { LandingHeader: window.Cura.LandingHeader });
