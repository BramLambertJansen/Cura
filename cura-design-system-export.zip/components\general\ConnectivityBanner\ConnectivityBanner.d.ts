import * as React from 'react';

/**
 * ConnectivityBanner — from cura@0.1.0.
 */
export interface ConnectivityBannerProps {
  [key: string]: unknown;
}

export declare const ConnectivityBanner: React.ComponentType<ConnectivityBannerProps>;
