import * as React from 'react';

/**
 * Leeg — from cura@0.1.0.
 */
export interface LeegProps {
  [key: string]: unknown;
}

export declare const Leeg: React.ComponentType<LeegProps>;
