import * as React from 'react';

/**
 * GroupCard — from cura@0.1.0.
 */
export interface GroupCardProps {
  [key: string]: unknown;
}

export declare const GroupCard: React.ComponentType<GroupCardProps>;
