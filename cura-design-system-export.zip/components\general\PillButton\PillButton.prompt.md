PillButton from cura. Use via `window.Cura.PillButton` (bundle loaded from the root `_ds_bundle.js`).
