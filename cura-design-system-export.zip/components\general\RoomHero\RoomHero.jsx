// Re-export of cura@0.1.0 RoomHero. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { RoomHero: window.Cura.RoomHero });
