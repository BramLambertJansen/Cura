import * as React from 'react';

/**
 * PrimaryButton — from cura@0.1.0.
 */
export interface PrimaryButtonProps {
  [key: string]: unknown;
}

export declare const PrimaryButton: React.ComponentType<PrimaryButtonProps>;
