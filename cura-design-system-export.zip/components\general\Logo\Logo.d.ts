import * as React from 'react';

/**
 * Logo — from cura@0.1.0.
 */
export interface LogoProps {
  [key: string]: unknown;
}

export declare const Logo: React.ComponentType<LogoProps>;
