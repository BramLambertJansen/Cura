// Re-export of cura@0.1.0 PullToRefreshIndicator. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { PullToRefreshIndicator: window.Cura.PullToRefreshIndicator });
