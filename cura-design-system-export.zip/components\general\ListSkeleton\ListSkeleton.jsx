// Re-export of cura@0.1.0 ListSkeleton. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { ListSkeleton: window.Cura.ListSkeleton });
