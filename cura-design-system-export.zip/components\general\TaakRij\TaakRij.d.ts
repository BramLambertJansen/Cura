import * as React from 'react';

/**
 * TaakRij — from cura@0.1.0.
 */
export interface TaakRijProps {
  [key: string]: unknown;
}

export declare const TaakRij: React.ComponentType<TaakRijProps>;
