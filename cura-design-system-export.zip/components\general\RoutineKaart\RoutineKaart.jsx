// Re-export of cura@0.1.0 RoutineKaart. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { RoutineKaart: window.Cura.RoutineKaart });
