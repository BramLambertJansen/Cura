import * as React from 'react';

/**
 * HintBanner — from cura@0.1.0.
 */
export interface HintBannerProps {
  [key: string]: unknown;
}

export declare const HintBanner: React.ComponentType<HintBannerProps>;
