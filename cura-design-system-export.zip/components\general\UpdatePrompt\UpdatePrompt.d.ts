import * as React from 'react';

/**
 * UpdatePrompt — from cura@0.1.0.
 */
export interface UpdatePromptProps {
  [key: string]: unknown;
}

export declare const UpdatePrompt: React.ComponentType<UpdatePromptProps>;
