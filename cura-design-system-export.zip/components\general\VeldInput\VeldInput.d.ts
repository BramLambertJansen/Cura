import * as React from 'react';

/**
 * VeldInput — from cura@0.1.0.
 */
export interface VeldInputProps {
  [key: string]: unknown;
}

export declare const VeldInput: React.ComponentType<VeldInputProps>;
