// Re-export of cura@0.1.0 Popover. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { Popover: window.Cura.Popover });
