import * as React from 'react';

/**
 * OptieKaart — from cura@0.1.0.
 */
export interface OptieKaartProps {
  [key: string]: unknown;
}

export declare const OptieKaart: React.ComponentType<OptieKaartProps>;
