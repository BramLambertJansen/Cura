KamerKunstKiezer from cura. Use via `window.Cura.KamerKunstKiezer` (bundle loaded from the root `_ds_bundle.js`).

Artwork picker for room create/edit — a grid of selectable room tiles that
shows the watercolor illustration where it exists and the tinted line-icon
fallback otherwise (via RoomThumb, so both stay one source of truth). Picking
a tile sets the room's `iconKey`; the image + color are derived from it, so
there's no separate persisted "image" field. Shared by NewRoomSheet and
EditRoomSheet instead of the old duplicated line-icon grids.
