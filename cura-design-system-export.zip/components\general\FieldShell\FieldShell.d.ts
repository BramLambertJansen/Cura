import * as React from 'react';

/**
 * FieldShell — from cura@0.1.0.
 */
export interface FieldShellProps {
  [key: string]: unknown;
}

export declare const FieldShell: React.ComponentType<FieldShellProps>;
