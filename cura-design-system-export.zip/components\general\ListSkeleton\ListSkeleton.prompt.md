ListSkeleton from cura. Use via `window.Cura.ListSkeleton` (bundle loaded from the root `_ds_bundle.js`).
