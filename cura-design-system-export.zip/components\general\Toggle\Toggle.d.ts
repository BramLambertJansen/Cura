import * as React from 'react';

/**
 * Toggle — from cura@0.1.0.
 */
export interface ToggleProps {
  [key: string]: unknown;
}

export declare const Toggle: React.ComponentType<ToggleProps>;
