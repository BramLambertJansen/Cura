RoutineKaart from cura. Use via `window.Cura.RoutineKaart` (bundle loaded from the root `_ds_bundle.js`).

## Related

`RoutineKaartCompact`
