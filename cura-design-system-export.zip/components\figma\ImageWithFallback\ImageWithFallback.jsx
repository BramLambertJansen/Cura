// Re-export of cura@0.1.0 ImageWithFallback. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { ImageWithFallback: window.Cura.ImageWithFallback });
