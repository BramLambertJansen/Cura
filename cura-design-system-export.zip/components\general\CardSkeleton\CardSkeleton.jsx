// Re-export of cura@0.1.0 CardSkeleton. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { CardSkeleton: window.Cura.CardSkeleton });
