import * as React from 'react';

/**
 * Kop — from cura@0.1.0.
 */
export interface KopProps {
  [key: string]: unknown;
}

export declare const Kop: React.ComponentType<KopProps>;
