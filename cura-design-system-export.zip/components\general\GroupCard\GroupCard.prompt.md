GroupCard from cura. Use via `window.Cura.GroupCard` (bundle loaded from the root `_ds_bundle.js`).
