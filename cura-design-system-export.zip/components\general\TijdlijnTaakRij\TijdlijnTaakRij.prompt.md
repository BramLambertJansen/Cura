TijdlijnTaakRij from cura. Use via `window.Cura.TijdlijnTaakRij` (bundle loaded from the root `_ds_bundle.js`).

A single task row inside Vandaag's dagdeel-tijdlijn — the timeline variant of
TaakRij. Rows sit directly inside one shared white group-card, without the
per-row card chrome (background/border/shadow) TaakRij carries elsewhere.
Everything else (swipe right to toggle, swipe left to dismiss, tap to edit,
timer button, interval/wekker badges) mirrors TaakRij exactly, so the
interaction language stays one thing across Vandaag/Huis/Taken — only the
visual shell differs here.
