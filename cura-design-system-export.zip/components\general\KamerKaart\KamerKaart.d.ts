import * as React from 'react';

/**
 * KamerKaart — from cura@0.1.0.
 */
export interface KamerKaartProps {
  [key: string]: unknown;
}

export declare const KamerKaart: React.ComponentType<KamerKaartProps>;
