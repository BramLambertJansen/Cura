import * as React from 'react';

/**
 * PullToRefreshIndicator — from cura@0.1.0.
 */
export interface PullToRefreshIndicatorProps {
  [key: string]: unknown;
}

export declare const PullToRefreshIndicator: React.ComponentType<PullToRefreshIndicatorProps>;
