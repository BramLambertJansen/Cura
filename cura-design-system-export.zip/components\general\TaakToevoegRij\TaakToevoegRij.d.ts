import * as React from 'react';

/**
 * TaakToevoegRij — from cura@0.1.0.
 */
export interface TaakToevoegRijProps {
  [key: string]: unknown;
}

export declare const TaakToevoegRij: React.ComponentType<TaakToevoegRijProps>;
