// Re-export of cura@0.1.0 FullScreenSkeleton. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { FullScreenSkeleton: window.Cura.FullScreenSkeleton });
