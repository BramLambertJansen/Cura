UpdatePrompt from cura. Use via `window.Cura.UpdatePrompt` (bundle loaded from the root `_ds_bundle.js`).

Headless — shows one calm, dismissable toast (not a hard reload or a browser confirm()) when a new build is ready.
