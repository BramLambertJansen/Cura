ConnectivityBanner from cura. Use via `window.Cura.ConnectivityBanner` (bundle loaded from the root `_ds_bundle.js`).

Calm offline/online notice. Local mode already works fully offline (it's
just localStorage), so it only gets a reassuring toast on the transition —
no persistent chrome. Cloud mode gets the same toast plus a small pill
while offline, since writes there genuinely can't sync until reconnected
and there's no offline write queue (yet) to promise otherwise.
