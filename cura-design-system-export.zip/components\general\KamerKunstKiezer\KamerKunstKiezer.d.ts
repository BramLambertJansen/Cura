import * as React from 'react';

/**
 * KamerKunstKiezer — from cura@0.1.0.
 */
export interface KamerKunstKiezerProps {
  [key: string]: unknown;
}

export declare const KamerKunstKiezer: React.ComponentType<KamerKunstKiezerProps>;
