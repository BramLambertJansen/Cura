// Re-export of cura@0.1.0 PageSkeleton. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { PageSkeleton: window.Cura.PageSkeleton });
