Toggle from cura. Use via `window.Cura.Toggle` (bundle loaded from the root `_ds_bundle.js`).
