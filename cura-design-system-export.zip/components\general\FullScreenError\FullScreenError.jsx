// Re-export of cura@0.1.0 FullScreenError. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { FullScreenError: window.Cura.FullScreenError });
