// Re-export of cura@0.1.0 Button. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { Button: window.Cura.Button });
