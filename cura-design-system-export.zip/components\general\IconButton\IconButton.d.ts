import * as React from 'react';

/**
 * IconButton — from cura@0.1.0.
 */
export interface IconButtonProps {
  [key: string]: unknown;
}

export declare const IconButton: React.ComponentType<IconButtonProps>;
