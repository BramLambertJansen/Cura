PopoverContent from cura. Use via `window.Cura.PopoverContent` (bundle loaded from the root `_ds_bundle.js`).
