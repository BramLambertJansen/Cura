import * as React from 'react';

/**
 * CardSkeleton — from cura@0.1.0.
 */
export interface CardSkeletonProps {
  [key: string]: unknown;
}

export declare const CardSkeleton: React.ComponentType<CardSkeletonProps>;
