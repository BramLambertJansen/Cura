import * as React from 'react';

/**
 * EmptyIllustration — from cura@0.1.0.
 */
export interface EmptyIllustrationProps {
  [key: string]: unknown;
}

export declare const EmptyIllustration: React.ComponentType<EmptyIllustrationProps>;
