// Re-export of cura@0.1.0 DubbelKnop. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { DubbelKnop: window.Cura.DubbelKnop });
