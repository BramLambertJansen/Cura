// Re-export of cura@0.1.0 Leeg. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { Leeg: window.Cura.Leeg });
