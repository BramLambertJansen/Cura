// Re-export of cura@0.1.0 AppBackground. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { AppBackground: window.Cura.AppBackground });
