import * as React from 'react';

/**
 * RingProgress — from cura@0.1.0.
 */
export interface RingProgressProps {
  [key: string]: unknown;
}

export declare const RingProgress: React.ComponentType<RingProgressProps>;
