// Re-export of cura@0.1.0 FocusMiniPill. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { FocusMiniPill: window.Cura.FocusMiniPill });
