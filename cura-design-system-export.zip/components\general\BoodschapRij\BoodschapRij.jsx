// Re-export of cura@0.1.0 BoodschapRij. Implementation is in the root _ds_bundle.js (window.Cura).
Object.assign(window, { BoodschapRij: window.Cura.BoodschapRij });
