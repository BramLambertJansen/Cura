RoomArt from cura. Use via `window.Cura.RoomArt` (bundle loaded from the root `_ds_bundle.js`).
