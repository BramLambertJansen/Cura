TimerDisplay from cura. Use via `window.Cura.TimerDisplay` (bundle loaded from the root `_ds_bundle.js`).

De grote timer-weergave: een ring die vult naarmate de tijd verstrijkt, met de
resterende m:ss in de Lora-koptekststijl in het midden. Deelt de bestaande
`RingProgress` (sage → zacht sage → goud bij afronden) zodat hij in dezelfde
familie past. De ring is `aria-hidden`; de tijd + fase-tekst dragen de
betekenis voor screenreaders.
