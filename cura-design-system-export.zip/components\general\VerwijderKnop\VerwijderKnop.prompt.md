VerwijderKnop from cura. Use via `window.Cura.VerwijderKnop` (bundle loaded from the root `_ds_bundle.js`).
